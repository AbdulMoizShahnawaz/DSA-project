import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class SignupInterface extends JFrame implements BankTheme {
    private RoundedTextField firstNameField, lastNameField, cnicField, passkeyField;
    private RoundedPasswordField passField;
    private BankOperations ops;

    public SignupInterface(BankOperations ops) {
        this.ops = ops;

        setTitle("CBM Bank - SIGNUP");
        setSize(500, 750); // Increased height slightly for better spacing
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_WHITE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Title
        JLabel title = new JLabel("JOIN CBM BANK", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(PRIMARY_PURPLE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        // --- CNIC Field Custom Setup ---
        cnicField = new RoundedTextField(15);
        cnicField.setText("XXXXX-XXXXXXX-X"); // Mask Placeholder
        cnicField.setForeground(Color.GRAY);

        // Add Focus Listener for Placeholder behavior
        cnicField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (cnicField.getText().equals("XXXXX-XXXXXXX-X")) {
                    cnicField.setText("");
                    cnicField.setForeground(Color.BLACK);
                }
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (cnicField.getText().isEmpty()) {
                    cnicField.setText("XXXXX-XXXXXXX-X");
                    cnicField.setForeground(Color.GRAY);
                }
            }
        });

        // Input Fields
        gbc.gridwidth = 1;
        addField(gbc, "First Name:", firstNameField = new RoundedTextField(15), 1);
        addField(gbc, "Last Name:", lastNameField = new RoundedTextField(15), 2);
        addField(gbc, "CNIC:", cnicField, 3);
        addField(gbc, "Password:", passField = new RoundedPasswordField(15), 4);
        addField(gbc, "Recovery Passkey:", passkeyField = new RoundedTextField(15), 5);

        // Signup Button
        JButton signupBtn = createRoundedButton("Create Account");
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        gbc.insets = new Insets(30, 20, 10, 20);
        add(signupBtn, gbc);

        signupBtn.addActionListener(e -> handleSignup());

        setVisible(true);
    }

    private void addField(GridBagConstraints gbc, String labelText, JComponent field, int row) {
        gbc.gridy = row; gbc.gridx = 0;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        add(label, gbc);
        gbc.gridx = 1;
        add(field, gbc);
    }

    private void handleSignup() {
        String fName = firstNameField.getText().trim();
        String lName = lastNameField.getText().trim();
        String cnic = cnicField.getText().trim();
        String pass = new String(passField.getPassword());
        String pKey = passkeyField.getText().trim();

        // 1. Basic Empty Validation
        if (fName.isEmpty() || cnic.isEmpty() || cnic.equals("XXXXX-XXXXXXX-X") || pass.isEmpty() || pKey.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are mandatory!", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Standard Pakistan CNIC Format Validation (Regex)
        // Format: 5 digits - 7 digits - 1 digit
        String cnicPattern = "^\\d{5}-\\d{7}-\\d{1}$";

        if (!cnic.matches(cnicPattern)) {
            JOptionPane.showMessageDialog(this,
                    "Invalid CNIC Format!\nPlease use: XXXXX-XXXXXXX-X\n(Include the dashes)",
                    "Format Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 3. Proceed to Register
        boolean success = ops.registerUser(fName, lName, cnic, pass, pKey);

        if (success) {
            JOptionPane.showMessageDialog(this, "Success! You can now login.", "Account Created", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "A user with this CNIC already exists.", "Duplicate User", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JButton createRoundedButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 30, 30));
                super.paintComponent(g2);
                g2.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(PRIMARY_PURPLE);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}