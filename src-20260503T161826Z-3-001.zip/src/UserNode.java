import java.util.*;

public class UserNode {
    String cnic, password, passKey, firstName, lastName;
    double balance;

    // Loan Fields
    double totalLoanDebt = 0;
    String activeLoanType = "None";
    Queue<Double> installmentQueue;
    Stack<String> transactionHistory;
    UserNode next;

    public UserNode(String firstName, String lastName, String cnic, String password, String passKey, double balance) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.cnic = cnic;
        this.password = password;
        this.passKey = passKey;
        this.balance = balance; // Use the provided balance
        this.transactionHistory = new Stack<>();
        this.installmentQueue = new LinkedList<>();
        this.next = null;
    }

    @Override
    public String toString() {
        String historyStr = transactionHistory.isEmpty() ? "empty" : String.join(";", transactionHistory);
        String emiStr = "none";
        if (!installmentQueue.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Double d : installmentQueue) sb.append(d).append(";");
            emiStr = sb.toString();  }
        return cnic + "," + password + "," + passKey + "," + firstName + "," + lastName + "," +
                balance + "," + historyStr + "," + totalLoanDebt + "," + activeLoanType + "," + emiStr;  }   }