import java.awt.Color;

public interface BankTheme {

    Color PRIMARY_PURPLE = new Color(102, 51, 153);
    Color BACKGROUND_WHITE = Color.WHITE;
    Color TEXT_BLACK = Color.BLACK;

}