import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.Stack;

public class AdminDashboardInterface extends JFrame implements BankTheme {
    private BankOperations ops;
    private JTable userTable;
    private DefaultTableModel tableModel;
    private JLabel liquidityLabel;

    public AdminDashboardInterface(BankOperations ops) {
        this.ops = ops;
        setTitle("Manager Control Panel - CBM Bank");
        setSize(1000, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_WHITE);
        setLayout(new BorderLayout());

        // --- 1. HEADER (Centered Title) ---
        JPanel header = new JPanel(new GridBagLayout());
        header.setBackground(new Color(45, 45, 45));
        header.setPreferredSize(new Dimension(1000, 100));
        JLabel title = new JLabel("BANK MANAGEMENT");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        header.add(title);
        add(header, BorderLayout.NORTH);

        // --- 2. MAIN CONTENT (Table & Search) ---
        JPanel mainContent = new JPanel(new BorderLayout(20, 20));
        mainContent.setBackground(BACKGROUND_WHITE);
        mainContent.setBorder(new EmptyBorder(30, 40, 30, 40));

        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(BACKGROUND_WHITE);
        JLabel sLabel = new JLabel("Manage Users: ");
        sLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        JButton deleteBtn = createRoundedButton("Delete Account");
        deleteBtn.setBackground(new Color(180, 40, 40)); // Dark red to signify danger
        searchPanel.add(deleteBtn);

        JButton searchBtn = createRoundedButton("Search & View History");
        searchBtn.setPreferredSize(new Dimension(250, 45));
        deleteBtn.addActionListener(e -> handleDelete());

        searchPanel.add(sLabel);
        searchPanel.add(searchBtn);
        mainContent.add(searchPanel, BorderLayout.NORTH);

        // User Table
        String[] columns = {"CNIC", "First Name", "Last Name", "Balance", "Debt"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }  };
        userTable = new JTable(tableModel);
        userTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userTable.setRowHeight(35);
        userTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        userTable.getTableHeader().setBackground(PRIMARY_PURPLE);
        userTable.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(userTable);
        mainContent.add(scrollPane, BorderLayout.CENTER);
        add(mainContent, BorderLayout.CENTER);

        // --- 3. BOTTOM PANEL (Liquidity & Logout) ---
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(BACKGROUND_WHITE);
        bottomPanel.setBorder(new EmptyBorder(0, 40, 30, 40));

        liquidityLabel = new JLabel("Bank Liquidity: $0.00");
        liquidityLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        liquidityLabel.setForeground(PRIMARY_PURPLE);

        JButton logoutBtn = createRoundedButton("Logout");
        logoutBtn.setBackground(new Color(150, 0, 0));
        logoutBtn.setPreferredSize(new Dimension(150, 45));

        bottomPanel.add(liquidityLabel, BorderLayout.WEST);
        bottomPanel.add(logoutBtn, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        // --- ACTIONS ---
        searchBtn.addActionListener(e -> handleAdminSearch());
        logoutBtn.addActionListener(e -> { new LoginInterface(); this.dispose(); });

        loadTableData();
        updateLiquidity();
        setVisible(true);  }

    private void loadTableData() {
        tableModel.setRowCount(0);
        UserNode temp = ops.getHead(); // Ensure getHead() exists in BankOperations
        while (temp != null) {
            tableModel.addRow(new Object[]{
                    temp.cnic, temp.firstName, temp.lastName,
                    "$" + String.format("%.2f", temp.balance),
                    "$" + String.format("%.2f", temp.totalLoanDebt)
            });
            temp = temp.next;    }  }

    private void handleAdminSearch() {
        String cnic = JOptionPane.showInputDialog(this, "Enter User CNIC to View Details/History:");
        if (cnic == null || cnic.trim().isEmpty()) return;

        UserNode user = ops.findUserByGUI_Admin(cnic.trim()); // Bridge method
        if (user != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Name: ").append(user.firstName).append(" ").append(user.lastName).append("\n");
            sb.append("Balance: $").append(user.balance).append("\n");
            sb.append("Debt: $").append(user.totalLoanDebt).append("\n\n");
            sb.append("--- Transaction History ---\n");

            if (user.transactionHistory.isEmpty()) {
                sb.append("No transactions found.");
            } else {
                Stack<String> tempStack = (Stack<String>) user.transactionHistory.clone();
                while (!tempStack.isEmpty()) {
                    sb.append("- ").append(tempStack.pop()).append("\n");   }  }

            JTextArea area = new JTextArea(sb.toString());
            area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            area.setEditable(false);
            JOptionPane.showMessageDialog(this, new JScrollPane(area), "User Record", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);  }  }

    private void updateLiquidity() {
        double total = ops.getTotalLiquidity();
        liquidityLabel.setText("Bank Liquidity: $" + String.format("%.2f", total));  }

    private JButton createRoundedButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 25, 25));
                super.paintComponent(g2);
                g2.dispose();  }  };

        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(PRIMARY_PURPLE);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;  }
    private void handleDelete() {
        String cnic = JOptionPane.showInputDialog(this, "Enter User CNIC to PERMANENTLY delete:");
        if (cnic == null || cnic.trim().isEmpty()) return;

        // Confirm before deleting
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete user: " + cnic + "?\nThis cannot be undone.",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = ops.deleteUserByCNIC(cnic.trim());
            if (success) {
                JOptionPane.showMessageDialog(this, "Account deleted successfully.");
                loadTableData();    // Refresh table to show user is gone
                updateLiquidity(); // Refresh bank total
            } else {
                JOptionPane.showMessageDialog(this, "User not found or could not be deleted.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }}