import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.Stack;

public class UserDashboardInterface extends JFrame implements BankTheme {
    private UserNode currentUser;
    private BankOperations ops;
    private JLabel balLabel;

    public UserDashboardInterface(UserNode user, BankOperations ops) {
        this.currentUser = user;
        this.ops = ops;

        setTitle("User Dashboard - CBM Bank");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_WHITE);
        setLayout(new BorderLayout());

        // --- 1. HEADER PANEL ---
        JPanel header = new JPanel(new GridBagLayout());
        header.setBackground(PRIMARY_PURPLE);
        header.setPreferredSize(new Dimension(1000, 120));

        JLabel welcome = new JLabel("Welcome, " + user.firstName + " " + user.lastName);
        welcome.setForeground(Color.WHITE);
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 28));
        header.add(welcome);
        add(header, BorderLayout.NORTH);

        // --- 2. MAIN CONTENT AREA ---
        JPanel mainContent = new JPanel(new GridBagLayout());
        mainContent.setBackground(BACKGROUND_WHITE);
        mainContent.setBorder(new EmptyBorder(20, 40, 40, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;

        // Balance Display
        balLabel = new JLabel("Current Balance: $" + String.format("%.2f", currentUser.balance), SwingConstants.CENTER);
        balLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.weighty = 0.2;
        mainContent.add(balLabel, gbc);

        // Menu Buttons
        gbc.gridwidth = 1; gbc.weighty = 0.4;

        JButton depBtn = createRoundedButton("Deposit Money");
        gbc.gridx = 0; gbc.gridy = 1;
        mainContent.add(depBtn, gbc);

        JButton withBtn = createRoundedButton("Withdraw Money");
        gbc.gridx = 1;
        mainContent.add(withBtn, gbc);

        JButton histBtn = createRoundedButton("Transaction History");
        gbc.gridx = 0; gbc.gridy = 2;
        mainContent.add(histBtn, gbc);

        JButton emiViewBtn = createRoundedButton("View EMI Schedule");
        gbc.gridx = 1;
        mainContent.add(emiViewBtn, gbc);

        JButton loanBtn = createRoundedButton("Apply for Loan");
        gbc.gridx = 0; gbc.gridy = 3;
        mainContent.add(loanBtn, gbc);

        JButton emiPayBtn = createRoundedButton("Pay EMI (Deposit)");
        gbc.gridx = 1;
        mainContent.add(emiPayBtn, gbc);

        // Logout
        gbc.gridy = 4; gbc.gridx = 0; gbc.gridwidth = 2;
        JButton logoutBtn = createRoundedButton("Logout System");
        logoutBtn.setBackground(new Color(180, 40, 40));
        mainContent.add(logoutBtn, gbc);

        add(mainContent, BorderLayout.CENTER);

        // --- 3. ACTIONS ---
        depBtn.addActionListener(e -> handleDeposit());
        withBtn.addActionListener(e -> handleWithdraw());
        histBtn.addActionListener(e -> showHistory());
        emiViewBtn.addActionListener(e -> showEMISchedule());
        loanBtn.addActionListener(e -> openLoanMenu());
        emiPayBtn.addActionListener(e -> handleEMIDeposit());
        logoutBtn.addActionListener(e -> { new LoginInterface(); this.dispose(); });

        setVisible(true);
    }

    private JButton createRoundedButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 30, 30));
                super.paintComponent(g2);
                g2.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(PRIMARY_PURPLE);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void handleDeposit() {
        String input = JOptionPane.showInputDialog(this, "Enter Deposit Amount (Min $100):");
        if (input != null && !input.isEmpty()) {
            try {
                double amt = Double.parseDouble(input);
                // Validation: Must be at least $100 and positive
                if (amt < 100) {
                    JOptionPane.showMessageDialog(this, "Minimum deposit amount is $100.", "Deposit Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                currentUser.balance += amt;
                currentUser.transactionHistory.push("Deposited: $" + amt);
                ops.saveAllToFile();
                refreshBalance();
                JOptionPane.showMessageDialog(this, "Successfully deposited $" + amt);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid numeric amount!");
            }
        }
    }

    private void handleWithdraw() {
        String input = JOptionPane.showInputDialog(this, "Enter Withdrawal Amount (Min $100):");
        if (input != null && !input.isEmpty()) {
            try {
                double amt = Double.parseDouble(input);
                // Validation: Must be at least $100 and positive
                if (amt < 100) {
                    JOptionPane.showMessageDialog(this, "Minimum withdrawal amount is $100.", "Withdrawal Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (amt <= currentUser.balance) {
                    currentUser.balance -= amt;
                    currentUser.transactionHistory.push("Withdrew: $" + amt);
                    ops.saveAllToFile();
                    refreshBalance();
                    JOptionPane.showMessageDialog(this, "Successfully withdrew $" + amt);
                } else {
                    JOptionPane.showMessageDialog(this, "Insufficient Funds!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid numeric amount!");
            }
        }
    }

    private void openLoanMenu() {
        // 1. Check for existing debt first
        if (currentUser.totalLoanDebt > 0) {
            String[] options = {"Pay from Balance", "Close"};
            int choice = JOptionPane.showOptionDialog(this,
                    "Active Loan: " + currentUser.activeLoanType + "\nRemaining Debt: $" + String.format("%.2f", currentUser.totalLoanDebt),
                    "Loan Services", 0, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 0) handlePayInstallmentFromBalance();
            return;
        }

        // 2. ENFORCE $5,000 MINIMUM BALANCE FOR NEW LOANS
        if (currentUser.balance < 5000) {
            JOptionPane.showMessageDialog(this,
                    "Ineligible for Loan!\nYou must have at least $5,000 in your account to apply.",
                    "Eligibility Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 3. Proceed with Loan Application
        String[] loans = {"Asaan ($7k)", "Sahulat ($10k)", "Karobaar ($15k)"};
        int type = JOptionPane.showOptionDialog(this, "Select Loan Type:", "Apply", 0, JOptionPane.QUESTION_MESSAGE, null, loans, loans[0]);
        if (type == -1) return;

        double amount = (type == 0) ? 7000 : (type == 1) ? 10000 : 15000;
        String name = (type == 0) ? "Asaan" : (type == 1) ? "Sahulat" : "Karobaar";

        currentUser.totalLoanDebt = amount;
        currentUser.activeLoanType = name;
        currentUser.balance += amount;

        currentUser.installmentQueue.clear();
        double monthly = amount / 12;
        for (int i = 0; i < 12; i++) currentUser.installmentQueue.add(monthly);

        currentUser.transactionHistory.push("Loan Approved: $" + amount);
        ops.saveAllToFile();
        refreshBalance();
        JOptionPane.showMessageDialog(this, "Loan Credited!");
    }

    private void handlePayInstallmentFromBalance() {
        if (currentUser.installmentQueue.isEmpty()) return;
        double emi = currentUser.installmentQueue.peek();
        if (currentUser.balance >= emi) {
            currentUser.balance -= emi;
            currentUser.totalLoanDebt -= emi;
            currentUser.installmentQueue.poll();
            currentUser.transactionHistory.push("EMI Paid: $" + emi);
            ops.saveAllToFile();
            refreshBalance();
            JOptionPane.showMessageDialog(this, "EMI Paid!");
        } else {
            JOptionPane.showMessageDialog(this, "Insufficient Balance to pay EMI!");
        }
    }

    private void handleEMIDeposit() {
        if (currentUser.totalLoanDebt <= 0) {
            JOptionPane.showMessageDialog(this, "No active loans to pay.");
            return;
        }

        double nextEMI = currentUser.installmentQueue.isEmpty() ? 0 : currentUser.installmentQueue.peek();
        String message = (nextEMI > 0) ?
                "Next EMI: $" + String.format("%.2f", nextEMI) + "\nEnter amount to pay (Min $100):" :
                "Enter payment amount (Min $100):";

        String input = JOptionPane.showInputDialog(this, message);
        if (input == null || input.isEmpty()) return;
        try {
            double deposit = Double.parseDouble(input);
            // Consistent with new business rules: Min $100 for all deposits
            if (deposit < 100) {
                JOptionPane.showMessageDialog(this, "Minimum payment amount is $100.");
                return;
            }

            currentUser.totalLoanDebt -= deposit;
            if (!currentUser.installmentQueue.isEmpty() && deposit >= nextEMI) {
                currentUser.installmentQueue.poll();
            }
            currentUser.transactionHistory.push("Loan Payment: $" + deposit);

            if (currentUser.totalLoanDebt <= 0) {
                currentUser.totalLoanDebt = 0;
                currentUser.activeLoanType = "None";
                currentUser.installmentQueue.clear();
                JOptionPane.showMessageDialog(this, "Loan fully repaid! EMI Schedule cleared.");
            } else {
                JOptionPane.showMessageDialog(this, "Payment Successful!");
            }
            ops.saveAllToFile();
            refreshBalance();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid numeric amount!");
        }
    }

    private void showHistory() {
        if (currentUser.transactionHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No transaction history.", "History", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        StringBuilder sb = new StringBuilder();
        Stack<String> tempStack = (Stack<String>) currentUser.transactionHistory.clone();
        while (!tempStack.isEmpty()) sb.append("- ").append(tempStack.pop()).append("\n");

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JOptionPane.showMessageDialog(this, new JScrollPane(textArea), "Transaction History", JOptionPane.PLAIN_MESSAGE);
    }

    private void showEMISchedule() {
        if (currentUser.installmentQueue == null || currentUser.installmentQueue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No active loan or pending EMIs.", "EMI Schedule", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        StringBuilder sb = new StringBuilder("Remaining Installments: " + currentUser.installmentQueue.size() + "\n\n");
        int count = 1;
        for (Double emi : currentUser.installmentQueue) {
            sb.append("Month ").append(count++).append(": $").append(String.format("%.2f", emi)).append("\n");
        }
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "EMI Queue Schedule", JOptionPane.PLAIN_MESSAGE);
    }

    private void refreshBalance() {
        balLabel.setText("Current Balance: $" + String.format("%.2f", currentUser.balance));
    }
}