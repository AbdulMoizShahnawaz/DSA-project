import java.util.*;
import java.io.*;

public class BankOperations {
    private UserNode head = null;
    private final String FILE_NAME = "users.txt";
    Scanner sc = new Scanner(System.in);

    public BankOperations() {
        loadFromFile();    }

    // --- 1. USER LOGIN LOGIC ---
    public UserNode userLogin() {
        System.out.print("\nEnter CNIC: ");
        String cnic = sc.next();
        UserNode current = findUser(cnic);

        if (current == null) {
            System.out.println("Login Failed: CNIC not found in system.");
            return null;  }

        System.out.print("Enter Password (or 'forgot'): ");
        String input = sc.next();

        if (input.equals(current.password)) {
            System.out.println("Login Successful!");
            return current;
        } else if (input.equalsIgnoreCase("forgot")) {
            System.out.print("Enter Recovery Passkey: ");
            if (sc.next().equals(current.passKey)) return current;
            else System.out.println("Verification Failed.");
        } return null; }

    // --- 2. USER SIGNUP LOGIC ---
    public void signup() {
        System.out.print("\nCNIC: "); String c = sc.next();
        if(findUser(c) != null) { System.out.println("User exists!"); return; }

        System.out.print("Password: "); String p = sc.next();
        System.out.print("Key: "); String k = sc.next();
        System.out.print("First Name: "); String f = sc.next();
        System.out.print("Last Name: "); String l = sc.next();

        UserNode n = new UserNode(f, l, c, p, k, 0.0);
        if (head == null) head = n;
        else {
            UserNode t = head; while(t.next != null) t = t.next; t.next = n; }
        saveAllToFile();
        System.out.println("Signup Success!"); }

    // --- 3. USER DASHBOARD ---
    public void userDashboard(UserNode user) {
        while (true) {
            System.out.println("\n--- DASHBOARD [" + user.firstName.toUpperCase() + "] ---");
            System.out.println("1. View Balance");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Transaction History (Stack)");
            System.out.println("5. Change Password");
            System.out.println("6. Loan Services (NEW)"); // New Option
            System.out.println("7. Pay Loan EMI (Direct Deposit)"); // New Option
            System.out.println("8. Logout");
            System.out.print("Choice: ");

            if(!sc.hasNextInt()) { sc.next(); continue; }
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.println("\n>>> Current Balance: $" + user.balance);
            } else if (choice == 2) {
                System.out.print("Deposit Amount: ");
                double d = sc.nextDouble();
                user.balance += d;
                user.transactionHistory.push("Deposited: $" + d);
                saveAllToFile();
            } else if (choice == 3) {
                System.out.print("Withdraw Amount: ");
                double w = sc.nextDouble();
                if (w <= user.balance) {
                    user.balance -= w;
                    user.transactionHistory.push("Withdrew: $" + w);
                    saveAllToFile();
                } else System.out.println("Error: Insufficient Funds.");
            } else if (choice == 4) {
                printHistory(user);
            } else if (choice == 5) {
                changePassword(user);
            } else if (choice == 6) {
                loanMenu(user); // Calls your loan logic
            } else if (choice == 7) {
                payEMIByDeposit(user);
            } else if(choice == 8) {
                break; } } }

    private void changePassword(UserNode user) {
        System.out.println("\n--- PASSWORD SECURITY ---");
        System.out.print("Verify via Current Password or Passkey: ");
        String auth = sc.next();

        if (auth.equals(user.password) || auth.equals(user.passKey)) {
            System.out.print("Enter New Password: ");
            user.password = sc.next();
            saveAllToFile();
            System.out.println("Success: Password updated.");
        } else {
            System.out.println("Error: Verification Failed."); } }

    private UserNode findUser(String cnic) {
        UserNode temp = head;
        while (temp != null) {
            if (temp.cnic.trim().equalsIgnoreCase(cnic.trim())) {
                return temp; }
            temp = temp.next; }
        return null; }

    private void printHistory(UserNode user) {
        if(user.transactionHistory.isEmpty()) {
            System.out.println("No recent transactions.");
            return;  }
        System.out.println("\n--- RECENT ACTIVITY ---");
        Stack<String> temp = (Stack<String>) user.transactionHistory.clone();
        while(!temp.isEmpty()) {
            System.out.println("- " + temp.pop());  }  }
    public void saveAllToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME, false))) {
            UserNode temp = head;
            while (temp != null) {
                pw.println(temp.toString());
                temp = temp.next; }
        } catch (IOException e) {
            System.out.println("Critical Error: Could not save data!"); } }

    private void loadFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        head = null;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] d = line.split(",");
                if (d.length >= 7) {
                    double savedBalance = Double.parseDouble(d[5]);
                    UserNode n = new UserNode(d[3], d[4], d[0], d[1], d[2], savedBalance);
                    if (!d[6].equals("empty")) {
                        String[] history = d[6].split(";");
                        for (String h : history) n.transactionHistory.push(h); }
                    if (d.length == 10) {
                        n.totalLoanDebt = Double.parseDouble(d[7]);
                        n.activeLoanType = d[8];
                        if (!d[9].equals("none") && !d[9].equals("empty")) {
                            String[] emis = d[9].split(";");
                            for (String e : emis) {
                                if (!e.isEmpty()) n.installmentQueue.add(Double.parseDouble(e));   }   }  }
                    if (head == null) head = n;
                    else {
                        UserNode temp = head;
                        while(temp.next != null) temp = temp.next;
                        temp.next = n; } } }
        } catch (Exception e) {
            System.out.println("Error reading database: " + e.getMessage());  }  }
    public void loanMenu(UserNode user) {
        if (user.totalLoanDebt > 0) {
            System.out.println("You already have an active loan of $" + user.totalLoanDebt);
            System.out.println("1. Pay Installment\n2. View EMI Schedule (Queue)\n3. Exit");
            int choice = sc.nextInt();
            if (choice == 1) payInstallment(user);
            else if (choice == 2) viewEMISchedule(user);
            return;  }

        if (user.balance < 5000) {
            System.out.println("Ineligible: You must have at least $5000 balance to apply for a loan.");
            return;  }

        System.out.println("\n--- LOAN APPLICATION ---");
        System.out.println("1. Asaan Loan ($7,000)");
        System.out.println("2. Sahulat Loan ($10,000)");
        System.out.println("3. Karobaar Loan ($15,000)");
        int type = sc.nextInt();

        double amount = 0;
        if (type == 1) amount = 7000;
        else if (type == 2) amount = 10000;
        else if (type == 3) amount = 15000;

        System.out.println("Choose Payment Plan:");
        System.out.println("1. One-time Investment (No installments)");
        System.out.println("2. 12 Months (Qist-e-Asaan)");
        System.out.println("3. 5 Years / 60 Months (Qist-e-Tafaasul)");
        int plan = sc.nextInt();

        user.totalLoanDebt = amount;
        user.balance += amount; // Give the money to the user

        if (plan == 2) {
            double emi = amount / 12;
            for (int i = 1; i <= 12; i++) user.installmentQueue.add(emi);
        } else if (plan == 3) {
            double emi = amount / 60;
            for (int i = 1; i <= 60; i++) user.installmentQueue.add(emi);  }
        System.out.println("Loan Approved! $" + amount + " added to your balance.");
        saveAllToFile(); }

    public void viewEMISchedule(UserNode user) {
        if (user.installmentQueue.isEmpty()) {
            System.out.println("No pending installments.");
            return;  }
        System.out.println("\n--- UPCOMING INSTALLMENTS ---");
        int count = 1;
        for (Double emi : user.installmentQueue) {
            System.out.println("Month " + (count++) + ": $" + String.format("%.2f", emi)); } }

    public void payInstallment(UserNode user) {
        if (user.installmentQueue.isEmpty()) {
            if (user.totalLoanDebt > 0) {
                System.out.print("Enter amount to pay towards loan: ");
                double pay = sc.nextDouble();
                user.totalLoanDebt -= pay;
            } else {
                System.out.println("No debt to pay."); }
        } else {
            double currentEMI = user.installmentQueue.peek();
            if (user.balance >= currentEMI) {
                user.balance -= currentEMI;
                user.totalLoanDebt -= currentEMI;
                user.installmentQueue.poll();
                System.out.println("Installment of $" + String.format("%.2f", currentEMI) + " paid.");
            } else {
                System.out.println("Insufficient balance to pay current installment.");  }  }
        saveAllToFile();
    }
    public void payEMIByDeposit(UserNode user) {
        if (user.totalLoanDebt <= 0) {
            System.out.println("You have no active loans or debt to pay.");
            return;
        }

        System.out.println("\n--- DIRECT EMI DEPOSIT ---");
        System.out.println("Current Total Debt: $" + String.format("%.2f", user.totalLoanDebt));

        if (!user.installmentQueue.isEmpty()) {
            double nextEMI = user.installmentQueue.peek();
            System.out.println("Next Scheduled EMI: $" + String.format("%.2f", nextEMI));
            System.out.print("Enter amount to deposit for Loan Payment: ");
            double depositAmount = sc.nextDouble();

            if (depositAmount >= nextEMI) {
                user.totalLoanDebt -= depositAmount;
                user.installmentQueue.poll();

                user.transactionHistory.push("Direct Loan Deposit: $" + depositAmount);

                System.out.println("Payment Successful! EMI cleared and debt reduced.");
                if (user.totalLoanDebt <= 0) {
                    user.totalLoanDebt = 0;
                    user.activeLoanType = "None";
                    System.out.println("Congratulations! Your loan is fully paid off.");  }
            } else {
                System.out.println("Error: Deposit must be at least the EMI amount ($" + nextEMI + ").");
            }
        } else {
            System.out.print("Enter amount to deposit against total debt: ");
            double depositAmount = sc.nextDouble();
            user.totalLoanDebt -= depositAmount;
            user.transactionHistory.push("Direct Debt Payment: $" + depositAmount);
            System.out.println("Payment applied to total debt."); }

        saveAllToFile(); }
    public void adminDashboard() {
        while (true) {
            System.out.println("\n--- ADMIN CONTROL PANEL ---");
            System.out.println("1. View All Registered Accounts");
            System.out.println("2. Search User & View History (Stack)");
            System.out.println("3. View Global Loan Report (Queue/Debt)");
            System.out.println("4. Delete/Close User Account");
            System.out.println("5. View Bank Total Liquidity");
            System.out.println("6. Logout Admin");
            System.out.print("Admin Choice: ");

            int choice = sc.nextInt();
            if (choice == 1) displayAllUsers();
            else if (choice == 2) adminSearchUser();
            else if (choice == 3) globalLoanReport();
            else if (choice == 4) deleteAccount();
            else if (choice == 5) calculateTotalLiquidity();
            else if (choice == 6) break; }  }

    private void displayAllUsers() {
        System.out.println("\n--- ALL USERS ---");
        UserNode temp = head;
        if (temp == null) System.out.println("No users in the system.");
        while (temp != null) {
            System.out.println("CNIC: " + temp.cnic + " | Name: " + temp.firstName + " " + temp.lastName + " | Balance: $" + temp.balance);
            temp = temp.next;  }  }

    private void adminSearchUser() {
        System.out.print("Enter CNIC to search: ");
        String cnic = sc.next();
        UserNode user = findUser(cnic);
        if (user != null) {
            System.out.println("User Found: " + user.firstName + " " + user.lastName);
            System.out.println("Current Balance: $" + user.balance);
            System.out.println("Loan Status: " + user.activeLoanType + " (Debt: $" + user.totalLoanDebt + ")");
            printHistory(user);
        } else System.out.println("User not found.");  }

    private void globalLoanReport() {
        System.out.println("\n--- ACTIVE LOANS REPORT ---");
        UserNode temp = head;
        boolean found = false;
        while (temp != null) {
            if (temp.totalLoanDebt > 0) {
                System.out.println("User: " + temp.firstName + " | Debt: $" + temp.totalLoanDebt + " | Pending EMIs: " + temp.installmentQueue.size());
                found = true; }
            temp = temp.next;  }
        if (!found) System.out.println("No active loans in the system.");  }

    private void calculateTotalLiquidity() {
        double total = 0;
        UserNode temp = head;
        while (temp != null) {
            total += temp.balance;
            temp = temp.next;
        }
        System.out.println("\n>>> Total Bank Liquidity (Sum of all user balances): $" + String.format("%.2f", total)); }

    private void deleteAccount() {
        System.out.print("Enter CNIC of account to delete: ");
        String cnic = sc.next();

        if (head == null) return;

        if (head.cnic.equals(cnic)) {
            head = head.next;
            System.out.println("Account deleted successfully.");
            saveAllToFile();
            return;  }

        UserNode temp = head;
        while (temp.next != null && !temp.next.cnic.equals(cnic)) {
            temp = temp.next;  }

        if (temp.next != null) {
            temp.next = temp.next.next;
            System.out.println("Account deleted.");
            saveAllToFile();
        } else {
            System.out.println("Account not found.");  }  }

    public UserNode validateLogin(String cnic, String password) {
        UserNode user = findUser(cnic);
        if (user != null && user.password.equals(password)) {
            return user;
        }
        return null;
    }

    // Bridge method for the GUI Recovery
    public UserNode validateRecovery(String cnic, String passKey) {
        UserNode user = findUser(cnic);
        if (user != null && user.passKey.equals(passKey)) {
            return user;
        }
        return null;
    }

    public UserNode findUserByGUI(String cnic, String password) {
        UserNode user = findUser(cnic.trim());
        if (user != null && user.password.equals(password)) {
            return user;  }
        return null;  }

    public UserNode recoverByPasskey(String cnic, String passKey) {
        UserNode user = findUser(cnic.trim());
        if (user != null && user.passKey.equals(passKey)) {
            return user;  }
        return null;  }

    public boolean registerUser(String fName, String lName, String cnic, String pass, String pKey) {
        if (findUser(cnic) != null) return false;
        UserNode newUser = new UserNode(fName, lName, cnic, pass, pKey, 0.0);
        insertUser(newUser);
        saveAllToFile();
        return true;  }

    public void insertUser(UserNode newNode) {
        if (head == null) {
            head = newNode;
        } else {
            UserNode temp = head;
            while (temp.next != null) {
                temp = temp.next;  }
            temp.next = newNode;  }  }

    public UserNode getHead() {
        return head;  }

    public double getTotalLiquidity() {
        double total = 0;
        UserNode temp = head;
        while (temp != null) {
            total += temp.balance;
            temp = temp.next;  }
        return total;  }

    public UserNode findUserByGUI_Admin(String cnic) {
        UserNode temp = head;
        while (temp != null) {
            if (temp.cnic.trim().equalsIgnoreCase(cnic)) return temp;
            temp = temp.next;
        }
        return null;  }

    public void deleteAccountByGUI(String cnic) {
        if (head == null) return;
        if (head.cnic.equals(cnic)) {
            head = head.next;
        } else {
            UserNode temp = head;
            while (temp.next != null && !temp.next.cnic.equals(cnic)) {
                temp = temp.next;
            }
            if (temp.next != null) temp.next = temp.next.next;   }
        saveAllToFile();  }
    public boolean deleteUserByCNIC(String cnic) {
        if (head == null) return false;

        // Case 1: The user to delete is at the Head
        if (head.cnic.trim().equalsIgnoreCase(cnic)) {
            head = head.next;
            saveAllToFile(); // Ensure the file is updated immediately
            return true;
        }

        // Case 2: Search for the node in the middle or end
        UserNode current = head;
        while (current.next != null) {
            if (current.next.cnic.trim().equalsIgnoreCase(cnic)) {
                // "Jump" over the deleted node
                current.next = current.next.next;
                saveAllToFile();
                return true;
            }
            current = current.next;
        }

        return false; // User not found
    } }