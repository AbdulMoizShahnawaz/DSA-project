import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.Stack;

public class LoginInterface extends JFrame implements BankTheme {
    private RoundedTextField cnicField;
    private RoundedPasswordField passField;
    private BankOperations ops;

    public LoginInterface() {
        ops = new BankOperations();
        setTitle("CBM Bank Login");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_WHITE);
        setLayout(new GridBagLayout());

        Font mainFont = new Font("Segoe UI", Font.BOLD, 16);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel title = new JLabel("CBM BANK - LOGIN", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(PRIMARY_PURPLE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        // CNIC
        gbc.gridwidth = 1; gbc.gridy = 1;
        JLabel cLabel = new JLabel("CNIC:");
        cLabel.setFont(mainFont);
        add(cLabel, gbc);
        cnicField = new RoundedTextField(15);
        gbc.gridx = 1;
        add(cnicField, gbc);

        // Password
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel pLabel = new JLabel("Password:");
        pLabel.setFont(mainFont);
        add(pLabel, gbc);
        passField = new RoundedPasswordField(15);
        gbc.gridx = 1;
        add(passField, gbc);

        // Login Button
        JButton loginBtn = createRoundedButton("Login");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(loginBtn, gbc);

        // Forgot Password Link
        JButton forgotBtn = new JButton("Forgot Password?");
        forgotBtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        forgotBtn.setForeground(PRIMARY_PURPLE);
        forgotBtn.setBorderPainted(false);
        forgotBtn.setContentAreaFilled(false);
        forgotBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gbc.gridy = 4;
        add(forgotBtn, gbc);

        JButton signupLink = new JButton("New here? Create Account");
        signupLink.setForeground(PRIMARY_PURPLE);
        signupLink.setBorderPainted(false);
        signupLink.setContentAreaFilled(false);
        gbc.gridy = 5;
        add(signupLink, gbc);
        signupLink.addActionListener(e -> new SignupInterface(ops));

        // Action Listeners
        loginBtn.addActionListener(e -> handleLogin());
        forgotBtn.addActionListener(e -> handleForgot());

        JButton adminLink = new JButton("Manager Access");
        adminLink.setFont(new Font("Segoe UI", Font.BOLD, 14));
        adminLink.setForeground(new Color(100, 100, 100)); // Subtle gray
        adminLink.setBorderPainted(false);
        adminLink.setContentAreaFilled(false);
        adminLink.setCursor(new Cursor(Cursor.HAND_CURSOR));

        gbc.gridy = 6;
        add(adminLink, gbc);
        adminLink.addActionListener(e -> {
            String pin = JOptionPane.showInputDialog(this, "Enter Manager Security PIN:");
            if ("1234".equals(pin)) { // Simple hardcoded PIN for now
                new AdminDashboardInterface(ops);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Unauthorized Access!", "Security", JOptionPane.ERROR_MESSAGE);
            }   });
        setVisible(true);  }

    private void handleLogin() {
        String cnic = cnicField.getText().trim();
        String pass = new String(passField.getPassword());

        UserNode user = ops.findUserByGUI(cnic, pass);

        if (user != null) {
            new UserDashboardInterface(user, ops);
            this.dispose(); // Close login window
        } else {
            JOptionPane.showMessageDialog(this, "Invalid CNIC or Password", "Login Failed", JOptionPane.ERROR_MESSAGE); }   }

    private void handleForgot() {
        String cnic = JOptionPane.showInputDialog(this, "Enter CNIC for Recovery:");
        if (cnic == null || cnic.isEmpty()) return;
        String key = JOptionPane.showInputDialog(this, "Enter Security Passkey:");
        if (key == null) return;
        UserNode user = ops.recoverByPasskey(cnic, key);
        if (user != null) {
            JOptionPane.showMessageDialog(this, "Identity Verified!\nYour Password is: " + user.password);
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect details.", "Error", JOptionPane.ERROR_MESSAGE); }  }

    private JButton createRoundedButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 30, 30));
                super.paintComponent(g2);
                g2.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(PRIMARY_PURPLE);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        return btn;
    }
}

class RoundedPasswordField extends JPasswordField {
    public RoundedPasswordField(int columns) {
        super(columns);
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); }
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth()-1, getHeight()-1, 20, 20));
        super.paintComponent(g2);
        g2.dispose();  }
    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.LIGHT_GRAY);
        g2.draw(new RoundRectangle2D.Double(0, 0, getWidth()-1, getHeight()-1, 20, 20));
        g2.dispose();   }   }